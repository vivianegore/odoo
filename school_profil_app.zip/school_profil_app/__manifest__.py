{
'name': ' Profils des établissements ',
'description': ' Gérer les établissements',
'author': 'Viviane Gore',
'depends': ['base'],
'data': [
'security/school_profil_security.xml',
'security/ir.model.access.csv',
'views/school_profil_menu.xml',
'views/school_profil_views.xml'
],
'application': True,
}